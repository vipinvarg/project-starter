// Horizontal Tab
 $(document).ready(function () {
    var $tabs = $('#horizontalTab');
    $tabs.responsiveTabs({
        rotate: false,
        startCollapsed: 'accordion',
        collapsible: 'accordion',
        setHash: true,
        click: function(e, tab) {
            $('.info').html('Tab <strong>' + tab.id + '</strong> clicked!');
        },
        activate: function(e, tab) {
            $('.info').html('Tab <strong>' + tab.id + '</strong> activated!');
        },
        activateState: function(e, state) {
            //console.log(state);
            $('.info').html('Switched from <strong>' + state.oldState + '</strong> state to <strong>' + state.newState + '</strong> state!');
        }
    });

    $('#start-rotation').on('click', function() {
        $tabs.responsiveTabs('startRotation', 1000);
    });
    $('#stop-rotation').on('click', function() {
        $tabs.responsiveTabs('stopRotation');
    });
    $('#start-rotation').on('click', function() {
        $tabs.responsiveTabs('active');
    });
    $('#enable-tab').on('click', function() {
        $tabs.responsiveTabs('enable', 3);
    });
    $('#disable-tab').on('click', function() {
        $tabs.responsiveTabs('disable', 3);
    });
    $('.select-tab').on('click', function() {
        $tabs.responsiveTabs('activate', $(this).val());
    });

});


//Main Menu
$('.main-nav ul li:has(ul)').addClass('submenu');
$('.main-nav ul li:has(ul)').append("<i></i>");
$('.main-nav ul i').click(function() {
    $(this).parent('li').toggleClass('open');
    $(this).parent('li').children('ul').slideToggle();
})

//Mobile Menu
$('.mob-btn').click(function() {
    if (!$('html').hasClass('show-menu')) {
        $('html').addClass('show-menu');
    } else {
        $('html').removeClass('show-menu');
    }
});

$('.overlay').click(function() {
    if ($('html').hasClass('show-menu')) {
        $('html').removeClass('show-menu');
    }
});

//Append and Prepend
$('.first ul').clone().prependTo('.main-nav').addClass('desk-hide')
$('.last ul').clone().appendTo('.main-nav').addClass('desk-hide')


// WOW
wow = new WOW(
  {
    animateClass: 'animated',
    offset:       100,
    callback:     function(box) {
      console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
    }
  }
);
wow.init();

// fixed header
var header = 0;
function scrollHead(){
    
    if ($(document).scrollTop() > 0) {
        if (header == 0) {
            header = 1;
            $('.header').addClass('slim-header');
        }
    } else {
        if (header == 1) {
            header = 0;
            $('.header').removeClass('slim-header');
        }
    }
}
scrollHead();

$(window).scroll( scrollHead)





